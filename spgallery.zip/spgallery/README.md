# spgallery plugin

e107 Gallery plugin commissioned by Spinning Planet and jointly open sourced by SP. 

This plugin is a customized version of the core Gallery plugin, created to provide a more streamlined and user-friendly experience.

Recommended for e107 Lite 2.3.4. Compatible with e107 2.4 when the core Gallery plugin is not installed.
If the core Gallery plugin was previously used, uninstall it and update the URL configuration preference via Tools → Preference Editor.

Full credit to the original e107 core development team.


👉 Watch the video on YouTube: https://www.youtube.com/watch?v=6ZjKkLU2GgQ
